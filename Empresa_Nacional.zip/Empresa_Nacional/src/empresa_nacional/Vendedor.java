/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa_nacional;

/**
 *
 * @author danitrigueros18
 */
public class Vendedor {

    public Vendedor(String nombre1) {
    }

    //Indico toda la informacion necesaria del vendedor
    public String nombre;
    public int cedula;
    public int codigo;
    public String sucursal;
    public String vehiculoPropio;

}
