/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa_nacional;

/**
 *
 * @author danitrigueros18
 */
public class Factura {
        //Indico toda la informacion necesaria que lleva la factura
    public String nombreCliente;
    public int cedulaCliente;
    public int codigoFactura;
    public int montoFactura;    
    public int numeroMes;    
    public String productosElectronicos;
    public String productosAutomotrices;
    public String productosConstruccion;
    

    
}


