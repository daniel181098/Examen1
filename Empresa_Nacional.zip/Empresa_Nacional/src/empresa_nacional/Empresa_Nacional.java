/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empresa_nacional;

import javax.swing.JOptionPane;

/**
 *
 * @author danitrigueros18
 */
public class Empresa_Nacional {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        //Solicito la informacion del vendedor
        
        String nombre = JOptionPane.showInputDialog("Escriba el nombre del vendedor");

        Vendedor Vendedor = new Vendedor(nombre);
        
        String cedula =JOptionPane.showInputDialog("Escriba la cedula del vendedor");

        String codigo =JOptionPane.showInputDialog("Escriba el codigo del vendedor");

        String sucursal =JOptionPane.showInputDialog("Escriba la sucursal del vendedor");

        String vehiculo =JOptionPane.showInputDialog("Tiene vehiculo si o no");
        
        
        

        
        JOptionPane.showMessageDialog(null, "El Agente Vendedor "+nombre+
                " Codigo "+ codigo +" en el mes de ");
        
     
        
        
        
        
        
        

        
        

    
    }
}
